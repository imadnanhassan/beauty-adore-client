const AdminLayout = () => {
  return (
    <div>
      <h1>AdminLayout Component</h1>
    </div>
  );
};

export default AdminLayout;
