
import './App.css'

function App() {

  return (
    <>
     <p className='text-4xl '>Hello World</p>
    </>
  )
}

export default App
